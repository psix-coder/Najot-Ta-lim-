from django.contrib import admin

# from .models import Travel, Klass, Hotel



# @admin.register(Klass)
# class KlassAdmin(admin.ModelAdmin):
#     list_display = ("name", "price")
#     search_fields = ("name",)
#
#
# @admin.register(Hotel)
# class HotelAdmin(admin.ModelAdmin):
#     list_display = ("name", "stars", "price")
#     search_fields = ("name",)
#     list_filter = ("stars",)
#
#
# @admin.register(Travel)
# class TravelAdmin(admin.ModelAdmin):
#     list_display = ("name", "klass", "hotel", "price", "term")
#     search_fields = ("name", "hotel__name", "klass__name")
#     list_filter = ("klass", "hotel", "term")
#     ordering = ("-term",)
#
#


