# from django.urls import path
#
# from .views import HotelView, TravelView, KlassView
#
#
# urlpatterns =[
#     path("class/", KlassView.as_view()),
#     # path('hotels/', HotelView.as_view()),
#     # path('hotels/<int:pk/>', HotelView.as_view()),
#
#     # path('transport-classes/', KlassView.as_view()),
#     # path('transport-classes/<int:pk>', KlassView.as_view()),
#
#     # path('travels/', TravelView.as_view()),
#     # path('travels/<int:pk>', TravelView.as_view()),
# ]