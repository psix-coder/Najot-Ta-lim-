let a = 10, b = 15
console.log(a + b)
console.log(a - b)
console.log(a / b)
console.log(a * b)
console.log(a == b)
console.log(a === b)
console.log(a < b)
console.log(a > b)
console.log(a >= b)
console.log(a <= b)


