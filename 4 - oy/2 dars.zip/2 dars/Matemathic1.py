# # 1 Topshiriq

# def RaqamlarYigindisi(n):
#     return sum(int(raqam) for raqam in str(n))

# son = 108
# print(RaqamlarYigindisi(son))

# # Yigindini topish uchun listdan foydalanilgan qisqa va lo'nda

