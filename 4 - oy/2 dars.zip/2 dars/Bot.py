from typing import Final
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

TOKEN: Final = "8154458815:AAGRlIxDQmCPNXbgTZMpd7W85Q-GJleEF6Y"  
BOT_USERNAME: Final = "@Able_uz_bot"

# Buyruqlar

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Men Able man! Iltimos biror narsa kiriting men javob beraman! ")


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Assalomu alaykum mendan foydalanayotganingiz uchun rahmat! Men Able man! Menga biror bir o'zingiz qiziqqan Davlat, Mahsina va hokazo lar haqida so'rang men malumot beraman!")


async def custom_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Bu maxsus buyruq! ")

async def plus_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Qoshimcha ma'lumot! ")

# Javoblar

def handle_responses(text: str) -> str:
    jarayonda: str = text.lower()

    if "salom" in jarayonda:
        return "Salom nma gap!"
    
    if "nma gap" in jarayonda:
        return "Tinchlik o'zlaridachi?"
    
    if "tinchlik" in jarayonda:
        return "Ha tinch bolinda har doim!"
    
    if "yaxshi" in jarayonda:
        return "Ha yaxshi bolinda har doim!"
    
    if "menga yordam kere" in jarayonda:
        return "Xosh qanday?"
    
    return "Uzur nma yozganligingizni tushuna olmadim ?"


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message_type: str = update.message.chat.type 
    text: str = update.message.text

    print(f'Foydalanuvchi ({update.message.chat.id}) in {message_type}: "{text}"')

    if message_type == "group":
        if BOT_USERNAME in text:
            new_text: str = text.replace(BOT_USERNAME, '').strip()
            response: str = handle_responses(new_text)
        else:
            return
    else:
        response: str = handle_responses(text)

    print('Bot:', response)
    await update.message.reply_text(response)


async def error(update: Update, context: ContextTypes.DEFAULT_TYPE):
    print(f'Yangilash {update} kelib chiqqan xatoni {context.error}')


if __name__ == '__main__':
    print('Bot ishlamoqda...')
    app = Application.builder().token(TOKEN).build()

    # Buyruqlar
    app.add_handler(CommandHandler('start', start_command))
    app.add_handler(CommandHandler('help', help_command))
    app.add_handler(CommandHandler('custom', custom_command))
    app.add_handler(CommandHandler('plus', plus_command))

    # Xabarlar
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    app.add_error_handler(error)
    
    # So'rovlar
    print("Ishlamoqda...")
    app.run_polling(poll_interval=3)

