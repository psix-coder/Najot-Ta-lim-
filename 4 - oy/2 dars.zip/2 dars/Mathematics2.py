#  2 Topshiriq

# from datetime import timedelta

# def vaqtni_ajrat(sekundlar):
#     vaqt = timedelta(seconds = sekundlar)
    
#     kun = vaqt.days
#     soat, qoldiq = divmod(vaqt.seconds, 3600)
#     minut, sekund = divmod(qoldiq, 60)

#     return f"{kun} kun, {soat} soat, {minut} minut, {sekund} sekund"

# sekundlar_soni = 100000
# natija = vaqtni_ajrat(sekundlar_soni)
# print(natija)

# Domla Divmod ikkita sonni qabul qili, ularni natijasini qoldigini bi vaqtda qaytaradi!
# deteteime esa ozim organganman bu python dasturlash tilida vaqtni, sanani ifodalash, manipulatsiya qilish uchun qulay vosita!