# from collections import namedtuple

# Mahsulutlar = namedtuple("Mahsulot",["product_name", "price", "quantity"])

# mahsulot1 = Mahsulutlar(product_name="Coca Cola",price=12_000, quantity=20)
# mahsulot2 = Mahsulutlar(product_name="Pepsi",price=14_000, quantity=50)
# mahsulot3 = Mahsulutlar(product_name="Adrenalin",price=18_000, quantity=40)

# mahsulot = [mahsulot1, mahsulot2, mahsulot3]
# for mahsulot in mahsulot:
#     print(f"Mahsulot: {mahsulot.product_name}, Narxi: {mahsulot.price} so'm, Miqdori: {mahsulot.quantity} dona")