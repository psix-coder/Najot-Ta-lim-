# from collections import namedtuple

# talaba = namedtuple("Talaba", ['name', 'age', 'major'])

# talaba1 = talaba(name="Jhon", age="17", major='Student')
# talaba2 = talaba(name="Abel", age="17", major='Student')
# talaba3 = talaba(name="Able", age="17", major='Student')


# talabalar = [talaba1, talaba2, talaba3]

# for talaba in talabalar:
#     print(f"Ism: {talaba.name}, Yosh: {talaba.age} Kasb: {talaba.major}")