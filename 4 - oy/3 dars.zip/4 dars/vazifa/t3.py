# from collections import namedtuple

# Shahar = namedtuple("Shahar",["city_name", 'country', "population"])

# shahar1 = Shahar(city_name='Tashkent', country= "Uzbekistan", population=3_075_000 )
# shahar2 = Shahar(city_name='Tokyo', country= "Yaponya", population=13_230_000 )
# shahar3 = Shahar(city_name='New York', country= "North America", population=629_000 )


# shaharlar = [shahar1, shahar2, shahar3]

# eng_katta_shahar = max(shaharlar, key=lambda shahar: shahar.population)

# print(f"Eng katta aholi punkitiga ega shahar: {eng_katta_shahar.city_name}      Aholsi: {eng_katta_shahar.population}       Davlati: {eng_katta_shahar.country}")