a = int(input("A sonni kiriting! "))
b = int(input("B sonni kiriting! "))
c = int(input("C sonni kiriting! "))
if a < b < c:
    print(True)
else:
    print(False)