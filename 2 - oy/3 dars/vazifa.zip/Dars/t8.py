a = int(input("A sonni kiriting! "))
b = int(input("B sonni kiriting! "))
if a and b % 2 == 0:
    print("kiritgan sonlaringiz toq son! ")
else:
    print("Toq son emas! ")