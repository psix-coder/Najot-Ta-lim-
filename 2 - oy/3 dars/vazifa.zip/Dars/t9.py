a = int(input("A sonni kiriting! "))
b = int(input("B sonni kiriting! "))
if a % 2 == 0 or b % 2 == 0:
    print(f"{a} toq son! ")
else:
    print(f"{b} toq son emas! ")