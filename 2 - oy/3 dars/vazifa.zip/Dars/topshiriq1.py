a = int(input("Sonni kiriting! "))
if a > 0:
    print(f"{a} musbat ") 
elif a < 0:
    print(f"{a}manfiy")
