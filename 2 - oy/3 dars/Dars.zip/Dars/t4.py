a = int(input("A sonni kiriting! "))
b = int(input("B sonni kiriting! "))
if a > 2 or b <= 3:
    print(True)
else: 
    print(False)