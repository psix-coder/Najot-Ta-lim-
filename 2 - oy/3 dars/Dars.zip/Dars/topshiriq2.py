a = int(input("Ixtiyoroy son kiriting! "))
if a % 2 == 0:  
    print(f"{a} Kiritgan soningiz toq son! ") 
else:
    print(f"{a} Kiritgan soningiz juft son! ")


# 2 chi va 3 topshiriq bitta dasturda!