a = int(input("Birinchi sonni kiriting: "))
b = int(input("Ikkinchi sonni kiriting: "))

if (a % 2 != 0 and b % 2 == 0) or (a % 2 == 0 and b % 2 != 0):
    print("1 ta son toq.")
else:
    print("2 lasi ham toq yoki 2 kalasi ham juft.") 
    