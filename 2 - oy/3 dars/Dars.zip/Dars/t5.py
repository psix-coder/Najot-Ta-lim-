a = int(input("A sonni kiriting! "))
b = int(input("B sonni kiriting! "))
if a >= 0 and b <-2:
    print(True)
else:
    print(False)