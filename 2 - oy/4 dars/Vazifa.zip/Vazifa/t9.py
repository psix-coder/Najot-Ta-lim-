a = int(input("a son kiriting:"))
b = int(input("b son kiriting:"))
ra = 0
for i in range(a, b + 1):
    ra += i*i

print(ra)