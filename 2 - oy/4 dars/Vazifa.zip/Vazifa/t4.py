c = int(input("1 kg konfet narxini kiriting! "))
for i in range(1,11):
    print(i*c)
