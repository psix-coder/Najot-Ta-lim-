k = int(input("k son nikiriting? "))
n = int(input("n sonni kiriting? "))
for i in range(n):
    print(k)