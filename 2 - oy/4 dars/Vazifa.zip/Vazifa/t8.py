a = int(input("a sonni kiriting? "))
b = int(input("b sonni kiriting? "))
for i in range(a,b + 1):
     result = result * i
print(result)