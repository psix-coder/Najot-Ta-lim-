a = int(input("a sonni kiriting? "))
b = int(input("b sonni kiriting? "))
result = 0
for i in range(a,b + 1):
     result = result + i
print(result)