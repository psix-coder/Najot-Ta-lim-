yoqtirgan_taomlar = []

yoqtirgan_taomlar.append("Osh")
yoqtirgan_taomlar.append("Manti")
yoqtirgan_taomlar.append("Lag'mon")

yoqtirgan_taomlar.insert(0, "Somsa")  
yoqtirgan_taomlar.insert(2, "Shashlik")  

print("Sizning yoqtirgan taomlaringiz:")
print(yoqtirgan_taomlar)