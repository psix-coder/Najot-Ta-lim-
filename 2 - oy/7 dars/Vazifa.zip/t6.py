def reverse_array(arr):
    reversed_arr = arr[::-1]

    return reversed_arr

arr = [1, 2, 3, 4, 5]
reversed_arr = reverse_array(arr)

print("Massiv teskari tartibda:")
print(reversed_arr)